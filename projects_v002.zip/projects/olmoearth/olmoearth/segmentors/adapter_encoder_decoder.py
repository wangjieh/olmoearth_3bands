from __future__ import annotations

from mmseg.registry import MODELS
from torch import Tensor

from ..segmentor import OlmoEarthEncoderDecoder


@MODELS.register_module()
class OlmoEarthAdapterEncoderDecoder(OlmoEarthEncoderDecoder):
    """OLMoEarth segmentor with a trainable input adapter before backbone."""

    def __init__(
        self,
        input_adapter: dict | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.input_adapter = (
            MODELS.build(input_adapter) if input_adapter is not None else None
        )

    def extract_feat(self, inputs: Tensor) -> tuple[Tensor, ...]:
        if self.input_adapter is not None:
            inputs = self.input_adapter(inputs)
        return super().extract_feat(inputs)
