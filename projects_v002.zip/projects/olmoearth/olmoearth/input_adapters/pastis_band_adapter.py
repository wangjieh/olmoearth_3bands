from __future__ import annotations

import torch
from mmengine.model import BaseModule
from mmseg.registry import MODELS
from torch import Tensor, nn


DEFAULT_PASTIS_S2_BANDS = (
    "B02",
    "B03",
    "B04",
    "B08",
    "B05",
    "B06",
    "B07",
    "B8A",
    "B11",
    "B12",
    "B01",
    "B09",
)

RGBNIR_TO_PASTIS_S2 = {
    "B": "B02",
    "G": "B03",
    "R": "B04",
    "NIR": "B08",
}


def _normalize_s2_band_name(value: str) -> str:
    value = str(value).strip().upper().replace("_", "").replace(" ", "")
    if len(value) == 2 and value.startswith("B") and value[1].isdigit():
        return f"B0{value[1]}"
    return value


def _normalize_rgbnir_band_name(value: str) -> str:
    return str(value).strip().upper().replace("_", "").replace(" ", "")


@MODELS.register_module()
class PastisBandAdapter(BaseModule):
    """Learnable per-timestep band adapter for PASTIS Sentinel-2 inputs.

    PASTIS is loaded as flattened band-major input with shape
    ``(B, in_bands * T, H, W)``. This module applies the same 1x1 convolution
    to every timestep and returns ``(B, out_bands * T, H, W)``.
    """

    def __init__(
        self,
        in_bands: int = 12,
        out_bands: int = 4,
        num_timesteps: int = 12,
        source_band_names: tuple[str, ...] = DEFAULT_PASTIS_S2_BANDS,
        out_band_names: tuple[str, ...] | None = None,
        init_from_s2_rgbnir: bool = True,
        bias: bool = True,
        init_cfg: dict | None = None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        self.in_bands = in_bands
        self.out_bands = out_bands
        self.num_timesteps = num_timesteps
        self.source_band_names = [
            _normalize_s2_band_name(band) for band in source_band_names
        ]
        if out_band_names is None:
            out_band_names = ("B", "G", "R", "NIR")[:out_bands]
        self.out_band_names = [
            _normalize_rgbnir_band_name(band) for band in out_band_names
        ]
        if len(self.source_band_names) != self.in_bands:
            raise ValueError(
                "source_band_names must have length "
                f"{self.in_bands}, got {len(self.source_band_names)}"
            )
        if len(self.out_band_names) != self.out_bands:
            raise ValueError(
                "out_band_names must have length "
                f"{self.out_bands}, got {len(self.out_band_names)}"
            )
        self.proj = nn.Conv2d(in_bands, out_bands, kernel_size=1, bias=bias)
        if init_from_s2_rgbnir:
            self._init_from_s2_rgbnir()

    def _init_from_s2_rgbnir(self) -> None:
        with torch.no_grad():
            self.proj.weight.zero_()
            if self.proj.bias is not None:
                self.proj.bias.zero_()
            for out_idx, out_band in enumerate(self.out_band_names):
                source_band = RGBNIR_TO_PASTIS_S2.get(out_band)
                if source_band is None:
                    raise ValueError(
                        "init_from_s2_rgbnir only supports output bands "
                        f"{tuple(RGBNIR_TO_PASTIS_S2)}, got {out_band!r}"
                    )
                source_idx = self.source_band_names.index(source_band)
                self.proj.weight[out_idx, source_idx, 0, 0] = 1.0

    def forward(self, inputs: Tensor) -> Tensor:
        if inputs.ndim != 4:
            raise ValueError(
                "PastisBandAdapter expects a 4D tensor "
                f"(B, C, H, W), got shape {tuple(inputs.shape)}"
            )
        batch_size, channels, height, width = inputs.shape
        expected_channels = self.in_bands * self.num_timesteps
        if channels != expected_channels:
            raise ValueError(
                f"PastisBandAdapter expected {expected_channels} channels "
                f"({self.in_bands} bands x {self.num_timesteps} timesteps), "
                f"got {channels}"
            )

        x = inputs.reshape(
            batch_size,
            self.in_bands,
            self.num_timesteps,
            height,
            width,
        )
        x = x.permute(0, 2, 1, 3, 4).reshape(
            batch_size * self.num_timesteps,
            self.in_bands,
            height,
            width,
        )
        x = self.proj(x)
        x = x.reshape(
            batch_size,
            self.num_timesteps,
            self.out_bands,
            height,
            width,
        )
        return x.permute(0, 2, 1, 3, 4).reshape(
            batch_size,
            self.out_bands * self.num_timesteps,
            height,
            width,
        )
