from __future__ import annotations

from mmseg.registry import MODELS

from .olmoearth_backbone import OlmoEarthBackbone


@MODELS.register_module()
class OlmoEarthRGBNIRBackbone(OlmoEarthBackbone):
    """OLMoEarth RGB branch wrapper for learned B/G/R/NIR inputs."""

    def __init__(
        self,
        *args,
        band_names: tuple[str, str, str, str] = ("B", "G", "R", "NIR"),
        **kwargs,
    ) -> None:
        self._rgbnir_band_names = list(band_names)
        kwargs.setdefault("modality", "rgb")
        kwargs.setdefault("trainable_bands", list(self._rgbnir_band_names))
        super().__init__(*args, **kwargs)
        self.band_names = list(self._rgbnir_band_names)

    def _present_bands_from_metainfo(self, batch_size: int) -> list[set[str]]:
        present = set(self._rgbnir_band_names)
        return [present for _ in range(batch_size)]
