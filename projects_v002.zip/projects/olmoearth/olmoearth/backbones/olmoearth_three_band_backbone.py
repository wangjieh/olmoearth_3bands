from __future__ import annotations

from mmseg.registry import MODELS

from .olmoearth_backbone import OlmoEarthBackbone


@MODELS.register_module()
class OlmoEarthThreeBandBackbone(OlmoEarthBackbone):
    """OLMoEarth backbone wrapper for three learned per-timestep bands."""

    def __init__(
        self,
        *args,
        band_names: tuple[str, str, str] = ("B1", "B2", "B3"),
        **kwargs,
    ) -> None:
        self._three_band_names = list(band_names)
        kwargs.setdefault("trainable_bands", list(self._three_band_names))
        super().__init__(*args, **kwargs)
        self.band_names = list(self._three_band_names)

    def _get_bandsets(self) -> list[list[str]]:
        return [[band] for band in self._three_band_names]

    def _present_bands_from_metainfo(self, batch_size: int) -> list[set[str]]:
        present = set(self._three_band_names)
        return [present for _ in range(batch_size)]
