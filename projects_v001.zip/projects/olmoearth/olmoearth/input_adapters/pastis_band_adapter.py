from __future__ import annotations

from mmengine.model import BaseModule
from mmseg.registry import MODELS
from torch import Tensor, nn


@MODELS.register_module()
class PastisBandAdapter(BaseModule):
    """Learnable per-timestep band adapter for PASTIS Sentinel-2 inputs.

    PASTIS is loaded as flattened band-major input with shape
    ``(B, in_bands * T, H, W)``. This module applies the same 1x1 convolution
    to every timestep and returns ``(B, out_bands * T, H, W)``.
    """

    def __init__(
        self,
        in_bands: int = 12,
        out_bands: int = 3,
        num_timesteps: int = 12,
        bias: bool = True,
        init_cfg: dict | None = None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        self.in_bands = in_bands
        self.out_bands = out_bands
        self.num_timesteps = num_timesteps
        self.proj = nn.Conv2d(in_bands, out_bands, kernel_size=1, bias=bias)

    def forward(self, inputs: Tensor) -> Tensor:
        if inputs.ndim != 4:
            raise ValueError(
                "PastisBandAdapter expects a 4D tensor "
                f"(B, C, H, W), got shape {tuple(inputs.shape)}"
            )
        batch_size, channels, height, width = inputs.shape
        expected_channels = self.in_bands * self.num_timesteps
        if channels != expected_channels:
            raise ValueError(
                f"PastisBandAdapter expected {expected_channels} channels "
                f"({self.in_bands} bands x {self.num_timesteps} timesteps), "
                f"got {channels}"
            )

        x = inputs.reshape(
            batch_size,
            self.in_bands,
            self.num_timesteps,
            height,
            width,
        )
        x = x.permute(0, 2, 1, 3, 4).reshape(
            batch_size * self.num_timesteps,
            self.in_bands,
            height,
            width,
        )
        x = self.proj(x)
        x = x.reshape(
            batch_size,
            self.num_timesteps,
            self.out_bands,
            height,
            width,
        )
        return x.permute(0, 2, 1, 3, 4).reshape(
            batch_size,
            self.out_bands * self.num_timesteps,
            height,
            width,
        )
